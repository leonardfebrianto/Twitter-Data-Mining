<?php
$query = $this->db->query("select * from result where username='".$username."'");

foreach($query->result() as $isi)
{
	$idresult = $isi->id_result;
}

echo "<b>Gender (Female)</b><br/>";
$query_gender = $this->db->query("select * from result_temp where id_result='".$idresult."' and kategori_1='Female'");
foreach($query_gender->result() as $isi)
{
	echo "".$isi->kategori_2." : ".$isi->hasil."<br/>";
}

echo "<b>Age (16-25 tahun)</b><br/>";
$query_gender = $this->db->query("select * from result_temp where id_result='".$idresult."' and kategori_1='16-25 tahun'");
foreach($query_gender->result() as $isi)
{
	echo "".$isi->kategori_2." : ".$isi->hasil."<br/>";
}
?>