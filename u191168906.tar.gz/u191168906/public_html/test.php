<!DOCTYPE html>
<html>
<head>
<style type="text/css">
h1
{
	letter-spacing:7px;
	color:white;
	font-weight:bold;
	text-shadow:5px 5px 5px black;
	font-family:"Arial Rounded MT Bold",sans-serif;
}

h2
{
	letter-spacing:4px;
	color:white;
	font-weight:bold;
	text-shadow:3px 3px 3px black;
	font-family:"Arial Rounded MT Bold",sans-serif;
}

body
{
	background-image: url('bg2.jpg');
    background-repeat: no-repeat;
    background-attachment: fixed;
	background-size:cover;
	width:100%;
	margin:0;
}

#wrapper
{
	width:100%;
	height:auto;
	min-height:25em;
	margin:0 auto;
	padding-top:8px;
}
#left
{
	width:99%;
	height:25em;
	margin:0 auto;
	display:box;
}

textarea
{
	width:40%;
	border-radius:3px;
	background-color:white;
}

input
{
	width:10em;
	height:3em;
	border-radius:5px;
	color:white;
	font-size:15px;
	font-family:"Arial Rounded MT Bold",sans-serif;
	font-weight:bold;
	background-color:#FF2929;
	box-shadow:3px 3px 2px 0px grey;
}

#right
{
	width:auto;
	min-width:20em;
	height:20em;
	margin:0 auto 50px auto;
	display:inline-block;
}

table
{
	border:1px solid black;
	border-collapse:collapse;
	width:100px;
	background-color:white;
	margin:0 auto;
}

table,th,td
{
	border:1px solid black;
	padding:0 10px;
}

.even {background-color:#fff;}
.odd {background-color:#F8F8F8;}
</style>
</head>
<body>
<center><h1>INPUT YOUR DATA :</h1></center>
<form method="post">
<div id="wrapper">
<div id="left"> 
<center>
<textarea rows="20" name="data" style="margin-right:20px;" placeholder="General Data...">
</textarea>
<textarea rows="20" name="data2" placeholder="Date Format Data...">
</textarea>
<br />

<input type="submit" name="submit" style="margin-top:10px;" value="Submit" />
<!--<input type="submit" name="export" style="margin-top:10px;" value="Export to Excel" />-->
</center>
</div>
<center>
<div id="right">
<?php
$username = [];
$hashtag = [];
$etc = [];
session_start();
if(isset($_POST['export']))
		{
			header('location:export_to_excel.php');
		}
if(isset($_POST['submit']))
{
	unset($_SESSION['username']);
	unset($_SESSION['hashtag']);
	unset($_SESSION['etc']);
	unset($_SESSION['tanggal']);
	$data = $_POST['data'];
	$data2 = $_POST['data2'];
	
	if($data != "" && $data2 != "")
	{
		echo "<input type='submit' name='export' value='Export to Excel' /><br />";
		$pattern = '/\?/';
		$replacement = '';
		$a = preg_replace($pattern, $replacement, $data);
		$pattern = '/\./';
		$replacement = '';
		$b = preg_replace($pattern, $replacement, $a);
		$pattern = '/\,/';
		$replacement = '';
		$c = preg_replace($pattern, $replacement, $b);
		$pattern = '/\!/';
		$replacement = '';
		$d = preg_replace($pattern, $replacement, $c);
		$e = preg_replace('/\s+/', ' ', $d);
		$result = array_count_values(explode(' ', $e));
		arsort($result);// not neccesary
		$s = explode(PHP_EOL, $data2);
		$s = array_count_values($s);
		echo "<br /><h2>RESULT : </h2><br />";
		echo ('<table align="left">
		<tr>
		<th>Username</th>
		<th>Jumlah</th>
		</tr>');
		foreach($result as $x=>$x_value)
		{
			$a = substr($x,0,1);
			if($a == "@")
			{
				$username[$x] = $x_value;
			}
			elseif($a == "#")
			{
				$hashtag[$x] = $x_value;
			}
			elseif ($x == date('Y-m-d H:i:s',strtotime($x)))
			{
				$tanggal[$x] = $x_value;
			}
			else
			{
				$etc[$x] = $x_value;
			}
			//echo "<tr><td>" . $x . "</td><td>" . $x_value . "</td></tr>";
		}
		
		if($username != null)
		{
			foreach($username as $user => $jumlah)
			{
				$currentState1 = ($currentState1 == 'odd' ? 'even' : 'odd');
				
				echo "<tr class='".$currentState1."'><td>" . $user . "</td><td>" . $jumlah . "</td></tr>";
			}		
		}
		
		echo "</table><table align='left'>";
		echo ('<th>Hashtag</th>
		<th>Jumlah</th>');
		if($hashtag != null)
		{
			foreach($hashtag as $user => $jumlah)
			{
				$currentState2 = ($currentState2 == 'odd' ? 'even' : 'odd');
				echo "<tr class='".$currentState2."'><td>" . $user . "</td><td>" . $jumlah . "</td></tr>";
			}		
		}
		//echo "<pre>";print_r($username);exit;
		
		echo "</table><table align='left'>";
		echo ('<th>Etc</th>
		<th>Jumlah</th>');
		
		if($etc != null)
		{
			foreach($etc as $user => $jumlah)
			{
				$currentState4 = ($currentState4 == 'odd' ? 'even' : 'odd');
				echo "<tr class='".$currentState4."'><td>" . $user . "</td><td>" . $jumlah . "</td></tr>";
			}		
		}
		//echo "<pre>";print_r($username);exit;
		echo "</table><table align='left'>";
		echo ('<th>Tanggal</th>
		<th>Jumlah</th>');
		
		if($s != null)
		{
			foreach($s as $user => $jumlah)
			{
				$currentState3 = ($currentState3 == 'odd' ? 'even' : 'odd');
				echo "<tr class='".$currentState3."'><td>" . $user . "</td><td>" . $jumlah . "</td></tr>";
			}		
		}
		echo "</table>";
		
		$_SESSION['username'] = $username;
		$_SESSION['hashtag'] = $hashtag;
		$_SESSION['etc'] = $etc;
		$_SESSION['tanggal'] = $s;
	}
	elseif($data != "")
	{
		echo "<input type='submit' name='export' value='Export to Excel' /><br />";
		$pattern = '/\?/';
		$replacement = '';
		$a = preg_replace($pattern, $replacement, $data);
		$pattern = '/\./';
		$replacement = '';
		$b = preg_replace($pattern, $replacement, $a);
		$pattern = '/\,/';
		$replacement = '';
		$c = preg_replace($pattern, $replacement, $b);
		$pattern = '/\!/';
		$replacement = '';
		$d = preg_replace($pattern, $replacement, $c);
		$e = preg_replace('/\s+/', ' ', $d);
		$result = array_count_values(explode(' ', $e));
		arsort($result);// not neccesary
		echo "<br /><h2>RESULT : </h2><br />";
		echo ('<table align="left">
		<tr>
		<th>Username</th>
		<th>Jumlah</th>
		</tr>');
		foreach($result as $x=>$x_value)
		{
			$a = substr($x,0,1);
			if($a == "@")
			{
				$username[$x] = $x_value;
			}
			elseif($a == "#")
			{
				$hashtag[$x] = $x_value;
			}
			elseif ($x == date('Y-m-d H:i:s',strtotime($x)))
			{
				$tanggal[$x] = $x_value;
			}
			else
			{
				$etc[$x] = $x_value;
			}
		}
		
		if($username != null)
		{
			foreach($username as $user => $jumlah)
			{
				$currentState1 = ($currentState1 == 'odd' ? 'even' : 'odd');
				
				echo "<tr class='".$currentState1."'><td>" . $user . "</td><td>" . $jumlah . "</td></tr>";
			}		
		}
		
		echo "</table><table align='left'>";
		echo ('<th>Hashtag</th>
		<th>Jumlah</th>');
		if($hashtag != null)
		{
			foreach($hashtag as $user => $jumlah)
			{
				$currentState2 = ($currentState2 == 'odd' ? 'even' : 'odd');
				echo "<tr class='".$currentState2."'><td>" . $user . "</td><td>" . $jumlah . "</td></tr>";
			}		
		}
		
		echo "</table><table align='left'>";
		echo ('<th>Etc</th>
		<th>Jumlah</th>');
		
		if($etc != null)
		{
			foreach($etc as $user => $jumlah)
			{
				$currentState4 = ($currentState4 == 'odd' ? 'even' : 'odd');
				echo "<tr class='".$currentState4."'><td>" . $user . "</td><td>" . $jumlah . "</td></tr>";
			}		
		}
		
		echo "</table><table align='left'>";
		echo ('<th>Tanggal</th>
		<th>Jumlah</th>');
		
		if($s != null)
		{
			foreach($s as $user => $jumlah)
			{
				$currentState3 = ($currentState3 == 'odd' ? 'even' : 'odd');
				echo "<tr class='".$currentState3."'><td>" . $user . "</td><td>" . $jumlah . "</td></tr>";
			}		
		}
		echo "</table>";
		$_SESSION['username'] = $username;
		$_SESSION['hashtag'] = $hashtag;
		$_SESSION['etc'] = $etc;
	}
	elseif($data2 != "")
	{
		$s = explode(PHP_EOL, $data2);
		$s = array_count_values($s);
		$_SESSION['tanggal'] = $s;
		echo "<input type='submit' name='export' value='Export to Excel' /><br />";
		echo "<br /><h2>RESULT : </h2><br />";
		echo ('<table align="left">
		<tr>
		<th>Username</th>
		<th>Jumlah</th>
		</tr>');
		echo "</table><table align='left'>";
		echo ('<th>Hashtag</th>
		<th>Jumlah</th>');
		echo "</table><table align='left'>";
		echo ('<th>Etc</th>
		<th>Jumlah</th>');
		echo "</table><table align='left'>";
		echo ('<th>Tanggal</th>
		<th>Jumlah</th>');
		if($s != null)
		{
			foreach($s as $user => $jumlah)
			{
				$currentState3 = ($currentState3 == 'odd' ? 'even' : 'odd');
				echo "<tr class='".$currentState3."'><td>" . $user . "</td><td>" . $jumlah . "</td></tr>";
			}		
		}
		echo "</table>";
	}
	else
	{
		echo ('<script>alert("Kolom masih kosong");</script>');
	}
}

?>
</div>
</center>
</div>
</form>
</body>
</html>