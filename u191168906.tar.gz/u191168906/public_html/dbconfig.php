<?php
	$server ="mysql.idhostinger.com";
	$user = "u191168906_inno";
	$pass ="Kakeknyemplung";
	$db ="u191168906_inno";
	
$conn = mysqli_connect($server,$user,$pass,$db);

if(mysqli_connect_error())
{	echo "Connection Failed";}

?>