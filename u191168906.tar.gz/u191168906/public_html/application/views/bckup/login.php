<html>
<head>
</head>
<body>
<form method="post" action="<?php echo base_url()?>verifylogin">
LOGIN<br/>
<input type="text" name="username" autocomplete=off required="required"/><br/>
<input type="password" name="password" autocomplete=off required="required"/><br/>
<input type="submit" name="submit" value="Login" />
</form>
</body>
</html>