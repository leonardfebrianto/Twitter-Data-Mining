<html>
<head>
</head>
<body>

<b>ADMIN DASHBOARD</b><br/>
<a href="<?php echo base_url();?>home/input/kategori">Input Kategori</a> |
<a href="<?php echo base_url();?>home/input/keyword">Input Keyword</a> |
<a href="<?php echo base_url();?>home/input/result">Input Result</a> |
<a href="<?php echo base_url();?>home/logout">Logout</a> |
</body>
</html>