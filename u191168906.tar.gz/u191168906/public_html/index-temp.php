<!DOCTYPE html>
<html>
<head>
<style type="text/css">
h1
{
	letter-spacing:7px;
	color:white;
	font-weight:bold;
	text-shadow:5px 5px 5px black;
	font-family:"Arial Rounded MT Bold",sans-serif;
}

h2
{
	letter-spacing:4px;
	color:white;
	font-weight:bold;
	text-shadow:3px 3px 3px black;
	font-family:"Arial Rounded MT Bold",sans-serif;
}

body
{
	background-color:grey;
	width:100%;
	margin:0;
}

#wrapper
{
	background-color:white;
	width:99%;
	height:auto;
	min-height:25em;
	margin:10px auto;
}
#left
{
	width:47.3em;
	height:60em; 
	display:box;
	background-color:blue;
}

textarea
{
	width:50em;
	height:44em;
	border-radius:3px;
	background-color:white;
	position:absolute;
	left:3.6em;
}


#holder
{
	width:10em;
	background-color:blue;
	height:2em;
	padding-top:10px;
	border:2px solid white;
	border-radius:18px;
	color:grey;
	position:absolute;
	top:60em;
	left:17em;
}

#holder a
{
	text-decoration:none;
	color:white;
	padding:0 3px; 
}

#right
{
	width:60%;
	min-width:20em;
	height:25em;
	display:inline-block;
}

#rightChild
{
	width:auto;
	min-width:20em;
	height:20em;
	margin:0 auto 50px auto;
	display:inline-block;	
}

table
{
	border:1px solid black;
	border-collapse:collapse;
	width:100px;
	background-color:white;
	margin:0 auto;
}

table,th,td
{
	border:1px solid black;
	padding:0 10px;
}

.even {background-color:#fff;}
.odd {background-color:#F8F8F8;}

@media screen and (max-width: 1920px) {
	#left
	{
		width:40%;
		height:62em; 
		display:box;
		background-color:blue;
		float:left;
	}
	
	#holder
	{
		width:10em;
		background-color:blue;
		height:2em;
		padding-top:10px;
		border:2px solid white;
		border-radius:18px;
		color:grey;
		position:absolute;
		top:50em;
		left:17em;
	}
	
	#submit
	{
		width:10em;
		height:3em;
		border-radius:5px;
		color:white;
		font-size:15px;
		font-family:"Arial Rounded MT Bold",sans-serif;
		font-weight:bold;
		background-color:#FF2929;
		box-shadow:3px 3px 2px 0px grey;
		position:absolute;
		top:58em;
		left:19em;
	}
	
	#export
	{
		background:none!important;
		border:none; 
		padding:0!important;
		font: inherit;
		/*border is optional*/
		border-bottom:1px solid #444; 
		cursor: pointer;
		position:absolute;
		top:40px;
		right:40px;
	}
	
	#right
	{
		width:60%;
		min-width:20em;
		min-height:62em;
		height:auto;
		display:inline-block;
	}

	#rightChild
	{
		width:auto;
		min-width:20em;
		min-height:61em;
		height:auto;
		margin:0 auto;
		display:inline-block;	
	}
}

@media screen and (max-width: 1680px) {
	#left
	{
		width:40%;
		height:60em; 
		display:box;
		background-color:blue;
		float:left;
	}
	
	#holder
	{
		width:10em;
		background-color:blue;
		height:2em;
		padding-top:10px;
		border:2px solid white;
		border-radius:18px;
		color:grey;
		position:absolute;
		top:50em;
		left:16em;
	}
	
	#submit
	{
		width:10em;
		height:3em;
		border-radius:5px;
		color:white;
		font-size:15px;
		font-family:"Arial Rounded MT Bold",sans-serif;
		font-weight:bold;
		background-color:#FF2929;
		box-shadow:3px 3px 2px 0px grey;
		position:absolute;
		top:58em;
		left:18em;
	}
	
	#export
	{
		background:none!important;
		border:none; 
		padding:0!important;
		font: inherit;
		/*border is optional*/
		border-bottom:1px solid #444; 
		cursor: pointer;
		position:absolute;
		top:40px;
		right:40px;
	}
	
	#right
	{
		width:60%;
		min-width:20em;
		min-height:60em;
		height:auto;
		display:inline-block;
	}

	#rightChild
	{
		width:auto;
		min-width:20em;
		min-height:59em;
		height:auto;
		margin:0 auto;
		display:inline-block;	
	}
	
	textarea
	{
		width:44em;
		height:44em;
		border-radius:3px;
		background-color:white;
		position:absolute;
		left:3.6em;
	}
}

@media screen and (max-width: 1600px) {
	#left
	{
		width:40%;
		height:50.5em; 
		display:box;
		background-color:blue;
		float:left;
	}
	
	#holder
	{
		width:10em;
		background-color:blue;
		height:2em;
		padding-top:10px;
		border:2px solid white;
		border-radius:18px;
		color:grey;
		position:absolute;
		top:41em;
		left:15em;
	}
	
	#submit
	{
		width:10em;
		height:3em;
		border-radius:5px;
		color:white;
		font-size:15px;
		font-family:"Arial Rounded MT Bold",sans-serif;
		font-weight:bold;
		background-color:#FF2929;
		box-shadow:3px 3px 2px 0px grey;
		position:absolute;
		top:48em;
		left:16.5em;
	}
	
	#export
	{
		background:none!important;
		border:none; 
		padding:0!important;
		font: inherit;
		/*border is optional*/
		border-bottom:1px solid #444; 
		cursor: pointer;
		position:absolute;
		top:40px;
		right:40px;
	}
	
	#right
	{
		width:60%;
		min-width:20em;
		min-height:50.5em;
		height:auto;
		display:inline-block;
	}

	#rightChild
	{
		width:auto;
		min-width:20em;
		min-height:49em;
		height:auto;
		margin:0 auto;
		display:inline-block;	
	}
	
	textarea
	{
		width:41em;
		height:35em;
		border-radius:3px;
		background-color:white;
		position:absolute;
		left:3.6em;
	}
}

@media screen and (max-width: 1440px) {
	#left
	{
		width:40%;
		height:50.5em; 
		display:box;
		background-color:blue;
		float:left;
	}
	
	#holder
	{
		width:10em;
		background-color:blue;
		height:2em;
		padding-top:10px;
		border:2px solid white;
		border-radius:18px;
		color:grey;
		position:absolute;
		top:41em;
		left:13em;
	}
	
	#submit
	{
		width:10em;
		height:3em;
		border-radius:5px;
		color:white;
		font-size:15px;
		font-family:"Arial Rounded MT Bold",sans-serif;
		font-weight:bold;
		background-color:#FF2929;
		box-shadow:3px 3px 2px 0px grey;
		position:absolute;
		top:48em;
		left:14em;
	}
	
	#export
	{
		background:none!important;
		border:none; 
		padding:0!important;
		font: inherit;
		/*border is optional*/
		border-bottom:1px solid #444; 
		cursor: pointer;
		position:absolute;
		top:40px;
		right:40px;
	}
	
	#right
	{
		width:60%;
		min-width:20em;
		min-height:50.5em;
		height:auto;
		display:inline-block;
	}

	#rightChild
	{
		width:auto;
		min-width:20em;
		min-height:49em;
		height:auto;
		margin:0 auto;
		display:inline-block;	
	}
	
	textarea
	{
		width:36em;
		height:35em;
		border-radius:3px;
		background-color:white;
		position:absolute;
		left:3.6em;
	}
}

@media screen and (max-width: 1400px) {
	#left
	{
		width:40%;
		height:62em; 
		display:box;
		background-color:blue;
		float:left;
	}
	
	#holder
	{
		width:10em;
		background-color:blue;
		height:2em;
		padding-top:10px;
		border:2px solid white;
		border-radius:18px;
		color:grey;
		position:absolute;
		top:50em;
		left:17em;
	}
	
	#submit
	{
		width:10em;
		height:3em;
		border-radius:5px;
		color:white;
		font-size:15px;
		font-family:"Arial Rounded MT Bold",sans-serif;
		font-weight:bold;
		background-color:#FF2929;
		box-shadow:3px 3px 2px 0px grey;
		position:absolute;
		top:58em;
		left:19em;
	}
	
	#export
	{
		background:none!important;
		border:none; 
		padding:0!important;
		font: inherit;
		/*border is optional*/
		border-bottom:1px solid #444; 
		cursor: pointer;
		position:absolute;
		top:40px;
		right:40px;
	}
	
	#right
	{
		width:60%;
		min-width:20em;
		min-height:62em;
		height:auto;
		display:inline-block;
	}

	#rightChild
	{
		width:auto;
		min-width:20em;
		min-height:61em;
		height:auto;
		margin:0 auto;
		display:inline-block;	
	}
	
	textarea
	{
		width:35em;
		height:44em;
		border-radius:3px;
		background-color:white;
		position:absolute;
		left:3.6em;
	}
}

@media screen and (max-width: 1366px) {
	#left
	{
		width:40%;
		height:62em; 
		display:box;
		background-color:blue;
		float:left;
	}
	
	#holder
	{
		width:10em;
		background-color:blue;
		height:2em;
		padding-top:10px;
		border:2px solid white;
		border-radius:18px;
		color:grey;
		position:absolute;
		top:50em;
		left:17em;
	}
	
	#submit
	{
		width:10em;
		height:3em;
		border-radius:5px;
		color:white;
		font-size:15px;
		font-family:"Arial Rounded MT Bold",sans-serif;
		font-weight:bold;
		background-color:#FF2929;
		box-shadow:3px 3px 2px 0px grey;
		position:absolute;
		top:58em;
		left:19em;
	}
	
	#export
	{
		background:none!important;
		border:none; 
		padding:0!important;
		font: inherit;
		/*border is optional*/
		border-bottom:1px solid #444; 
		cursor: pointer;
		position:absolute;
		top:40px;
		right:40px;
	}
	
	#right
	{
		width:60%;
		min-width:20em;
		min-height:62em;
		height:auto;
		display:inline-block;
	}

	#rightChild
	{
		width:auto;
		min-width:20em;
		min-height:61em;
		height:auto;
		margin:0 auto;
		display:inline-block;	
	}
	
	textarea
	{
		width:34em;
		height:44em;
		border-radius:3px;
		background-color:white;
		position:absolute;
		left:3.6em;
	}
}

@media screen and (max-width: 1280px) {
	#title 
	{
		overflow: hidden;
		font-size: 90px;
		margin: 0 auto -580px;
		width: 100%;
		height: 1300px;
		position: relative;
		padding-top: 30px;
		z-index: 99;
	}
}

@media screen and (max-width: 1024px) {
	#title 
	{
		overflow: hidden;
		font-size: 70px;
		margin: 0 auto -580px;
		width: 100%;
		height: 1090px;
		position: relative;
		padding-top: 30px;
		z-index: 99;
	}
</style>
</head>
<body>
<form method="post">
<div id="wrapper">
<div id="left"> 
<center>
<img src="innovuz.png" width="200px" height="85px" /><br />
<h2>String Analysis Software</h2>
<textarea name="data" id="a" style="margin-right:20px;" align="center" placeholder="General Data...">
</textarea>
<textarea name="data2" id="b" placeholder="Date Format Data...">
</textarea>
<br /><br />
<div id="holder"> 
<a href="#" onClick=fadeA(); id="text">Text</a> | <a href="#" onClick=fadeB(); id="tgl">Date</a>
</div>
<br /><br />
<input type="submit" id="submit" name="submit" style="margin-top:10px;" value="Submit" />
</center>
</div>
<div id="right">
<center>
<div id="rightChild">
<?php
$username = [];
$hashtag = [];
$etc = [];
session_start();
if(isset($_POST['export']))
		{
			header('location:export_to_excel.php');
		}
if(isset($_POST['submit']))
{
	unset($_SESSION['username']);
	unset($_SESSION['hashtag']);
	unset($_SESSION['etc']);
	unset($_SESSION['tanggal']);
	$data = $_POST['data'];
	$data2 = $_POST['data2'];
	
	if($data != "" && $data2 != "")
	{
		echo "<input type='submit' name='export' value='Download file' id='export' /><br />";
		$pattern = '/\?/';
		$replacement = '';
		$a = preg_replace($pattern, $replacement, $data);
		$pattern = '/\./';
		$replacement = '';
		$b = preg_replace($pattern, $replacement, $a);
		$pattern = '/\,/';
		$replacement = '';
		$c = preg_replace($pattern, $replacement, $b);
		$pattern = '/\!/';
		$replacement = '';
		$d = preg_replace($pattern, $replacement, $c);
		$e = preg_replace('/\s+/', ' ', $d);
		$result = array_count_values(explode(' ', $e));
		arsort($result);// not neccesary
		$s = explode(PHP_EOL, $data2);
		$s = array_count_values($s);
		echo "<br /><h2 style='color:blue;text-shadow:3px 3px 3px #c9c4f9;'>RESULT : </h2><br />";
		echo ('<table align="left">
		<tr>
		<th>Username</th>
		<th>Jumlah</th>
		</tr>');
		foreach($result as $x=>$x_value)
		{
			$a = substr($x,0,1);
			if($a == "@")
			{
				$username[$x] = $x_value;
			}
			elseif($a == "#")
			{
				$hashtag[$x] = $x_value;
			}
			elseif ($x == date('Y-m-d H:i:s',strtotime($x)))
			{
				$tanggal[$x] = $x_value;
			}
			else
			{
				$etc[$x] = $x_value;
			}
			//echo "<tr><td>" . $x . "</td><td>" . $x_value . "</td></tr>";
		}
		
		if($username != null)
		{
			foreach($username as $user => $jumlah)
			{
				$currentState1 = ($currentState1 == 'odd' ? 'even' : 'odd');
				
				echo "<tr class='".$currentState1."'><td>" . $user . "</td><td>" . $jumlah . "</td></tr>";
			}		
		}
		
		echo "</table><table align='left'>";
		echo ('<th>Hashtag</th>
		<th>Jumlah</th>');
		if($hashtag != null)
		{
			foreach($hashtag as $user => $jumlah)
			{
				$currentState2 = ($currentState2 == 'odd' ? 'even' : 'odd');
				echo "<tr class='".$currentState2."'><td>" . $user . "</td><td>" . $jumlah . "</td></tr>";
			}		
		}
		//echo "<pre>";print_r($username);exit;
		
		echo "</table><table align='left'>";
		echo ('<th>Etc</th>
		<th>Jumlah</th>');
		
		if($etc != null)
		{
			foreach($etc as $user => $jumlah)
			{
				$currentState4 = ($currentState4 == 'odd' ? 'even' : 'odd');
				echo "<tr class='".$currentState4."'><td>" . $user . "</td><td>" . $jumlah . "</td></tr>";
			}		
		}
		//echo "<pre>";print_r($username);exit;
		echo "</table><table align='left'>";
		echo ('<th>Tanggal</th>
		<th>Jumlah</th>');
		
		if($s != null)
		{
			foreach($s as $user => $jumlah)
			{
				$currentState3 = ($currentState3 == 'odd' ? 'even' : 'odd');
				echo "<tr class='".$currentState3."'><td>" . $user . "</td><td>" . $jumlah . "</td></tr>";
			}		
		}
		echo "</table>";
		
		$_SESSION['username'] = $username;
		$_SESSION['hashtag'] = $hashtag;
		$_SESSION['etc'] = $etc;
		$_SESSION['tanggal'] = $s;
	}
	elseif($data != "")
	{
		echo "<input type='submit' name='export' value='Download file' id='export' /><br />";
		$pattern = '/\?/';
		$replacement = '';
		$a = preg_replace($pattern, $replacement, $data);
		$pattern = '/\./';
		$replacement = '';
		$b = preg_replace($pattern, $replacement, $a);
		$pattern = '/\,/';
		$replacement = '';
		$c = preg_replace($pattern, $replacement, $b);
		$pattern = '/\!/';
		$replacement = '';
		$d = preg_replace($pattern, $replacement, $c);
		$e = preg_replace('/\s+/', ' ', $d);
		$result = array_count_values(explode(' ', $e));
		arsort($result);// not neccesary
		echo "<br /><h2 style='color:blue;text-shadow:3px 3px 3px #c9c4f9;'>RESULT : </h2><br />";
		echo ('<table align="left">
		<tr>
		<th>Username</th>
		<th>Jumlah</th>
		</tr>');
		foreach($result as $x=>$x_value)
		{
			$a = substr($x,0,1);
			if($a == "@")
			{
				$username[$x] = $x_value;
			}
			elseif($a == "#")
			{
				$hashtag[$x] = $x_value;
			}
			elseif ($x == date('Y-m-d H:i:s',strtotime($x)))
			{
				$tanggal[$x] = $x_value;
			}
			else
			{
				$etc[$x] = $x_value;
			}
		}
		
		if($username != null)
		{
			foreach($username as $user => $jumlah)
			{
				$currentState1 = ($currentState1 == 'odd' ? 'even' : 'odd');
				
				echo "<tr class='".$currentState1."'><td>" . $user . "</td><td>" . $jumlah . "</td></tr>";
			}		
		}
		
		echo "</table><table align='left'>";
		echo ('<th>Hashtag</th>
		<th>Jumlah</th>');
		if($hashtag != null)
		{
			foreach($hashtag as $user => $jumlah)
			{
				$currentState2 = ($currentState2 == 'odd' ? 'even' : 'odd');
				echo "<tr class='".$currentState2."'><td>" . $user . "</td><td>" . $jumlah . "</td></tr>";
			}		
		}
		
		echo "</table><table align='left'>";
		echo ('<th>Etc</th>
		<th>Jumlah</th>');
		
		if($etc != null)
		{
			foreach($etc as $user => $jumlah)
			{
				$currentState4 = ($currentState4 == 'odd' ? 'even' : 'odd');
				echo "<tr class='".$currentState4."'><td>" . $user . "</td><td>" . $jumlah . "</td></tr>";
			}		
		}
		
		echo "</table><table align='left'>";
		echo ('<th>Tanggal</th>
		<th>Jumlah</th>');
		
		if($s != null)
		{
			foreach($s as $user => $jumlah)
			{
				$currentState3 = ($currentState3 == 'odd' ? 'even' : 'odd');
				echo "<tr class='".$currentState3."'><td>" . $user . "</td><td>" . $jumlah . "</td></tr>";
			}		
		}
		echo "</table>";
		$_SESSION['username'] = $username;
		$_SESSION['hashtag'] = $hashtag;
		$_SESSION['etc'] = $etc;
	}
	elseif($data2 != "")
	{
		$s = explode(PHP_EOL, $data2);
		$s = array_count_values($s);
		$_SESSION['tanggal'] = $s;
		echo "<input type='submit' name='export' value='Download file' id='export' /><br />";
		echo "<br /><h2 style='color:blue;text-shadow:3px 3px 3px #c9c4f9;'>RESULT : </h2><br />";
		echo ('<table align="left">
		<tr>
		<th>Username</th>
		<th>Jumlah</th>
		</tr>');
		echo "</table><table align='left'>";
		echo ('<th>Hashtag</th>
		<th>Jumlah</th>');
		echo "</table><table align='left'>";
		echo ('<th>Etc</th>
		<th>Jumlah</th>');
		echo "</table><table align='left'>";
		echo ('<th>Tanggal</th>
		<th>Jumlah</th>');
		if($s != null)
		{
			foreach($s as $user => $jumlah)
			{
				$currentState3 = ($currentState3 == 'odd' ? 'even' : 'odd');
				echo "<tr class='".$currentState3."'><td>" . $user . "</td><td>" . $jumlah . "</td></tr>";
			}		
		}
		echo "</table>";
	}
	else
	{
		echo ('<script>alert("Kolom masih kosong");</script>');
	}
}

?>
</div>
</center>
</div>
</div>
</form>
<script type="text/javascript">
document.getElementById('a').style.zIndex = "10";
document.getElementById('text').style.fontWeight = "bold";
document.getElementById('b').style.zIndex = "-10";

function fadeA()
{
	var textA = document.getElementById('a');
	var textB = document.getElementById('b');
	document.getElementById('tgl').style.fontWeight = "normal";
	document.getElementById('text').style.fontWeight = "bold";
	textA.style.zIndex = "10";
	textB.style.zIndex = "-10";
}

function fadeB()
{
	var textA = document.getElementById('a');
	var textB = document.getElementById('b');
	textA.style.zIndex = "-10";
	textB.style.zIndex = "10";
	document.getElementById('text').style.fontWeight = "normal";
	document.getElementById('tgl').style.fontWeight = "bold";
}
</script>
</body>
</html>